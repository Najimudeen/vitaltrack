import streamlit as st
from utils.analysis import analyze_bp
from utils.auth import login
from utils.export import export_summary

st.title("VitalTrack - Hypertension Tracker")
login()

st.sidebar.header("Upload BP Data")
uploaded_file = st.sidebar.file_uploader("Upload CSV", type=["csv"])

if uploaded_file:
    st.success("File uploaded successfully!")
    analysis = analyze_bp(uploaded_file)
    st.write(analysis)
    if st.button("Export Summary"):
        export_summary(analysis)