import pandas as pd

def analyze_bp(file):
    df = pd.read_csv(file)
    df['Status'] = df['Systolic'].apply(lambda x: 'High' if x >= 140 else 'Normal')
    return df.describe(include='all')