import pandas as pd
import streamlit as st

def export_summary(data):
    data.to_csv("summary.csv")
    st.success("Exported summary to summary.csv")